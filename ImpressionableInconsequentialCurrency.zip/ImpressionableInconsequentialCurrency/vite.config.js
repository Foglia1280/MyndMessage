// Simulazione database utenti e chat

const users = [];
const chats = [];
let currentUser = null;
let currentChat = null;
let isRegisterMode = false;

// Registra il Service Worker per la PWA
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('Service Worker registrato'))
        .catch(err => console.error('Errore registrazione Service Worker:', err));
}

// Schermate
const authScreen = document.getElementById('auth-screen');
const chatListScreen = document.getElementById('chat-list-screen');
const chatScreen = document.getElementById('chat-screen');
const profileScreen = document.getElementById('profile-screen');

// Gestione login/registrazione
document.getElementById('auth-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const name = document.getElementById('name').value.trim();
    const photo = document.getElementById('photo').files[0];
    const errorMessage = document.getElementById('error-message');

    if (isRegisterMode) {
        // Registrazione
        if (!name) {
            errorMessage.textContent = 'Il nome è obbligatorio per la registrazione!';
            return;
        }
        if (users.some(user => user.username === username)) {
            errorMessage.textContent = 'Questo numero (username) è già in uso!';
            return;
        }
        const photoUrl = photo ? URL.createObjectURL(photo) : 'default.jpg';
        currentUser = {
            username,
            password, // In un'app reale, usa hash (es. bcrypt)
            name,
            photoUrl,
            privacy: { showLastSeen: true, visibility: 'everyone' }
        };
        users.push(currentUser);
        alert('Registrazione completata! Ora accedi.');
        toggleRegister();
    } else {
        // Login
        const user = users.find(user => user.username === username && user.password === password);
        if (user) {
            currentUser = user;
            // Crea o verifica chat con se stesso
            if (!chats.some(chat => chat.isSelfChat && chat.participants.includes(currentUser.username))) {
                const selfChat = {
                    id: `self_chat_${currentUser.username}`,
                    isSelfChat: true,
                    isGroup: false,
                    participants: [currentUser.username],
                    messages: [{ 
                        id: `msg_${Date.now()}`, 
                        sender: currentUser.username, 
                        content: 'Benvenuto nella tua chat personale!', 
                        type: 'text', 
                        timestamp: new Date(), 
                        status: 'read' 
                    }]
                };
                chats.push(selfChat);
            }
            authScreen.classList.add('hidden');
            chatListScreen.classList.remove('hidden');
            updateChatList();
        } else {
            errorMessage.textContent = 'Numero (username) o password errati!';
        }
    }
});

// Toggle tra login e registrazione
function toggleRegister() {
    isRegisterMode = !isRegisterMode;
    const loginBtn = document.getElementById('login-btn');
    const nameInput = document.getElementById('name').parentElement;
    const photoInput = document.getElementById('photo').parentElement;
    loginBtn.textContent = isRegisterMode ? 'Registrati' : 'Accedi';
    nameInput.style.display = isRegisterMode ? 'block' : 'none';
    photoInput.style.display = isRegisterMode ? 'block' : 'none';
    document.getElementById('auth-form').querySelector('h2').textContent = isRegisterMode ? 'Registrati a Mind Message' : 'Accedi a Mind Message';
    document.getElementById('error-message').textContent = '';
}

// Mostra profilo
function showProfile() {
    document.getElementById('profile-photo').src = currentUser.photoUrl;
    document.getElementById('profile-name').textContent = currentUser.name;
    document.getElementById('profile-username').textContent = currentUser.username;
    document.getElementById('show-last-seen').checked = currentUser.privacy.showLastSeen;
    document.getElementById('profile-visibility').value = currentUser.privacy.visibility;
    chatListScreen.classList.add('hidden');
    profileScreen.classList.remove('hidden');
}

// Salva impostazioni profilo
function saveProfile() {
    currentUser.privacy.showLastSeen = document.getElementById('show-last-seen').checked;
    currentUser.privacy.visibility = document.getElementById('profile-visibility').value;
    alert('Impostazioni salvate!');
    backToChatList();
}

// Torna alla lista chat
function backToChatList() {
    chatScreen.classList.add('hidden');
    profileScreen.classList.add('hidden');
    chatListScreen.classList.remove('hidden');
    updateChatList();
}

// Sincronizza contatti (simulato)
function syncContacts() {
    const contacts = users.filter(user => user.username !== currentUser.username).map(user => user.username);
    alert(`Contatti sincronizzati: ${contacts.join(', ') || 'Nessun contatto trovato'}`);
}

// Aggiorna lista chat
function updateChatList() {
    const chatList = document.getElementById('chat-list');
    chatList.innerHTML = '';
    chats.forEach(chat => {
        const chatItem = document.createElement('div');
        chatItem.classList.add('chat-item');
        chatItem.textContent = chat.isSelfChat ? 'Chat con me stesso' : (chat.isGroup ? `Gruppo: ${chat.name}` : chat.participants.find(p => p !== currentUser.username));
        chatItem.onclick = () => {
            currentChat = chat;
            document.getElementById('chat-title').textContent = chat.isSelfChat ? 'Chat con me stesso' : (chat.isGroup ? chat.name : chat.participants.find(p => p !== currentUser.username));
            chatListScreen.classList.add('hidden');
            chatScreen.classList.remove('hidden');
            updateMessages();
        };
        chatList.appendChild(chatItem);
    });
}

// Inizia nuova chat 1-to-1
function startNewChat() {
    const username = prompt('Inserisci il numero (username) del contatto:').trim();
    if (users.some(user => user.username === username)) {
        const chat = {
            id: `chat_${Date.now()}`,
            isSelfChat: username === currentUser.username,
            isGroup: false,
            participants: [currentUser.username, username],
            messages: []
        };
        if (!chats.some(c => c.participants.includes(currentUser.username) && c.participants.includes(username) && !c.isGroup)) {
            chats.push(chat);
        }
        currentChat = chat;
        document.getElementById('chat-title').textContent = chat.isSelfChat ? 'Chat con me stesso' : username;
        chatListScreen.classList.add('hidden');
        chatScreen.classList.remove('hidden');
        updateMessages();
    } else {
        alert('Utente non trovato!');
    }
}

// Inizia nuova chat di gruppo
function startGroupChat() {
    const groupName = prompt('Inserisci il nome del gruppo:').trim();
    const usernames = prompt('Inserisci i numeri (username) dei membri, separati da virgola:').split(',').map(u => u.trim());
    if (usernames.every(u => users.some(user => user.username === u))) {
        const chat = {
            id: `group_${Date.now()}`,
            isSelfChat: false,
            isGroup: true,
            name: groupName,
            participants: [currentUser.username, ...usernames],
            messages: []
        };
        chats.push(chat);
        currentChat = chat;
        document.getElementById('chat-title').textContent = groupName;
        chatListScreen.classList.add('hidden');
        chatScreen.classList.remove('hidden');
        updateMessages();
    } else {
        alert('Uno o più username non validi!');
    }
}

// Invia messaggio
function sendMessage() {
    const input = document.getElementById('message-input');
    const media = document.getElementById('media-input').files[0];
    const messages = document.getElementById('chat-messages');

    if (input.value || media) {
        const message = {
            id: `msg_${Date.now()}`,
            sender: currentUser.username,
            content: input.value,
            media: media ? URL.createObjectURL(media) : null,
            type: media ? media.type.split('/')[0] : 'text',
            timestamp: new Date(),
            status: 'sent'
        };
        currentChat.messages.push(message);
        updateMessages();
        alert(`Messaggio inviato a ${currentChat.isSelfChat ? 'te stesso' : (currentChat.isGroup ? currentChat.name : currentChat.participants.find(p => p !== currentUser.username))}`);

        // Simula stato messaggio
        setTimeout(() => {
            message.status = 'delivered';
            updateMessages();
            setTimeout(() => {
                message.status = 'read';
                updateMessages();
            }, 1000);
        }, 1000);

        // Simula risposta automatica (tranne per chat con se stesso)
        if (!currentChat.isSelfChat) {
            setTimeout(() => {
                const reply = {
                    id: `msg_${Date.now()}`,
                    sender: currentChat.participants.find(p => p !== currentUser.username) || 'Bot',
                    content: 'Risposta automatica!',
                    type: 'text',
                    timestamp: new Date(),
                    status: 'delivered'
                };
                currentChat.messages.push(reply);
                updateMessages();
                alert(`Nuovo messaggio da ${reply.sender}`);
            }, 2000);
        }

        input.value = '';
        document.getElementById('media-input').value = '';
    }
}

// Aggiorna messaggi
function updateMessages() {
    const messages = document.getElementById('chat-messages');
    messages.innerHTML = '';
    currentChat.messages.forEach(msg => {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', msg.sender === currentUser.username ? 'sent' : 'received');
        if (msg.type === 'image') {
            const img = document.createElement('img');
            img.src = msg.media;
            messageDiv.appendChild(img);
        } else if (msg.type === 'video') {
            const video = document.createElement('video');
            video.src = msg.media;
            video.controls = true;
            messageDiv.appendChild(video);
        } else if (msg.type === 'audio') {
            const audio = document.createElement('audio');
            audio.src = msg.media;
            audio.controls = true;
            messageDiv.appendChild(audio);
        } else {
            messageDiv.textContent = msg.content;
        }
        const status = document.createElement('span');
        status.classList.add('status');
        status.textContent = msg.status;
        messageDiv.appendChild(status);
        messages.appendChild(messageDiv);
    });
    messages.scrollTop = messages.scrollHeight;
}